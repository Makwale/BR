(self["webpackChunkBR"] = self["webpackChunkBR"] || []).push([["main"],{

/***/ 8255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 8255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _pages_driver_menudriver_menudriver_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/driver/menudriver/menudriver.page */ 5653);
/* harmony import */ var _pages_home_home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/home/home.page */ 678);
/* harmony import */ var _pages_menu_menu_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/menu/menu.page */ 7506);
/* harmony import */ var _pages_signin_signin_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/signin/signin.page */ 2590);
/* harmony import */ var _pages_signup_signup_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/signup/signup.page */ 4374);








const routes = [
    {
        path: '',
        redirectTo: 'welcome',
        pathMatch: 'full'
    },
    {
        path: 'menu',
        component: _pages_menu_menu_page__WEBPACK_IMPORTED_MODULE_2__.MenuPage,
        children: [
            {
                path: '',
                component: _pages_home_home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage
            },
            {
                path: 'signin',
                component: _pages_signin_signin_page__WEBPACK_IMPORTED_MODULE_3__.SigninPage
            },
            {
                path: 'signup',
                component: _pages_signup_signup_page__WEBPACK_IMPORTED_MODULE_4__.SignupPage
            },
            {
                path: 'bookings',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_bookings_bookings_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/bookings/bookings.module */ 3582)).then(m => m.BookingsPageModule)
            },
            {
                path: 'map',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_map_map_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/map/map.module */ 6016)).then(m => m.MapPageModule)
            },
            {
                path: 'account',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_account_account_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/account/account.module */ 6868)).then(m => m.AccountPageModule)
            },
        ],
    },
    {
        path: 'searchbus',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_searchbus_searchbus_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/searchbus/searchbus.module */ 3465)).then(m => m.SearchbusPageModule)
    },
    {
        path: 'editpic',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_editpic_editpic_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/editpic/editpic.module */ 6701)).then(m => m.EditpicPageModule)
    },
    {
        path: 'welcome',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_welcome_welcome_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/welcome/welcome.module */ 2282)).then(m => m.WelcomePageModule)
    },
    {
        path: 'menudriver',
        component: _pages_driver_menudriver_menudriver_page__WEBPACK_IMPORTED_MODULE_0__.MenudriverPage,
        children: [
            {
                path: '',
                redirectTo: 'login',
                pathMatch: 'full'
            },
            {
                path: 'login',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_driver_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/driver/login/login.module */ 1371)).then(m => m.LoginPageModule)
            },
            {
                path: 'home',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_driver_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/driver/home/home.module */ 7911)).then(m => m.HomePageModule)
            },
            {
                path: 'account',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_driver_account_account_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/driver/account/account.module */ 3045)).then(m => m.AccountPageModule)
            },
        ]
    },
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_driver_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/driver/home/home.module */ 7911)).then(m => m.HomePageModule)
    },
    {
        path: 'scanner',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_driver_scanner_scanner_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/driver/scanner/scanner.module */ 579)).then(m => m.ScannerPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_7__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 1106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 3069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let AppComponent = class AppComponent {
    constructor() { }
};
AppComponent.ctorParameters = () => [];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _pages_menu_menu_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/menu/menu.page */ 7506);
/* harmony import */ var _pages_signup_signup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/signup/signup.page */ 4374);
/* harmony import */ var _pages_signin_signin_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/signin/signin.page */ 2590);
/* harmony import */ var _pages_home_home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/home/home.page */ 678);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/platform-browser/animations */ 5835);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/fire */ 57);
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/fire/database */ 4134);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/fire/storage */ 8274);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/auth.service */ 7556);
/* harmony import */ var _pages_driver_menudriver_menudriver_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/driver/menudriver/menudriver.page */ 5653);
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ 2760);






















const firebaseConfig = {
    apiKey: "AIzaSyCvsvYeDkWYPNVJdVtdFvt7PpQirycbaxI",
    authDomain: "bus-project-52efc.firebaseapp.com",
    projectId: "bus-project-52efc",
    storageBucket: "bus-project-52efc.appspot.com",
    messagingSenderId: "789865770058",
    appId: "1:789865770058:web:7fa8ee99ecfaa262ad4ab3",
    measurementId: "G-Z3FSFN8C7X"
};
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent, _pages_menu_menu_page__WEBPACK_IMPORTED_MODULE_2__.MenuPage, _pages_signup_signup_page__WEBPACK_IMPORTED_MODULE_3__.SignupPage, _pages_signin_signin_page__WEBPACK_IMPORTED_MODULE_4__.SigninPage, _pages_home_home_page__WEBPACK_IMPORTED_MODULE_5__.HomePage, _pages_driver_menudriver_menudriver_page__WEBPACK_IMPORTED_MODULE_7__.MenudriverPage],
        entryComponents: [],
        imports: [
            _angular_fire__WEBPACK_IMPORTED_MODULE_11__.AngularFireModule.initializeApp(firebaseConfig),
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_12__.AngularFireAuthModule,
            _angular_fire_database__WEBPACK_IMPORTED_MODULE_13__.AngularFireDatabaseModule,
            _angular_fire_storage__WEBPACK_IMPORTED_MODULE_14__.AngularFireStorageModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_15__.MatInputModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__.MatFormFieldModule,
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.ReactiveFormsModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__.BrowserAnimationsModule
        ],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_21__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonicRouteStrategy }, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormBuilder, _services_auth_service__WEBPACK_IMPORTED_MODULE_6__.AuthService, _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__.BarcodeScanner],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 3652:
/*!******************************************!*\
  !*** ./src/app/modells/booking.model.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Booking": () => (/* binding */ Booking)
/* harmony export */ });
class Booking {
    constructor(id, slot, studentId, cancelled) {
        this.id = id;
        this.slot = slot;
        this.studentId = studentId;
        this.cancelled = cancelled ? cancelled : false;
    }
}


/***/ }),

/***/ 7751:
/*!*****************************************!*\
  !*** ./src/app/modells/driver.model.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Driver": () => (/* binding */ Driver)
/* harmony export */ });
/* harmony import */ var _user_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user.model */ 6095);

class Driver extends _user_model__WEBPACK_IMPORTED_MODULE_0__.User {
    constructor(id, firstname, lastname, phone, email, imgURL) {
        super(id, firstname, lastname, email, imgURL);
        this.phone = phone;
    }
}


/***/ }),

/***/ 6610:
/*!***************************************!*\
  !*** ./src/app/modells/slot.model.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Slot": () => (/* binding */ Slot)
/* harmony export */ });
class Slot {
    constructor(id, date, bus, geo, availableSeats, bookedSeats, from, to) {
        this.geo = [];
        this.id = id;
        this.date = date.toDate();
        this.bus = bus;
        this.from = from;
        this.to = to;
        this.geo = geo;
        this.availableSeats = availableSeats;
        this.bookedSeats = bookedSeats;
    }
}


/***/ }),

/***/ 8244:
/*!******************************************!*\
  !*** ./src/app/modells/student.model.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Student": () => (/* binding */ Student)
/* harmony export */ });
/* harmony import */ var _user_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user.model */ 6095);

class Student extends _user_model__WEBPACK_IMPORTED_MODULE_0__.User {
    constructor(id, firstname, lastname, studentNumber, email, imgURL) {
        super(id, firstname, lastname, email, imgURL);
        this.studentNumber = studentNumber;
    }
}


/***/ }),

/***/ 6095:
/*!***************************************!*\
  !*** ./src/app/modells/user.model.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "User": () => (/* binding */ User)
/* harmony export */ });
class User {
    constructor(id, firstname, lastname, email, imgURL) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.imgURL = imgURL;
    }
}


/***/ }),

/***/ 8455:
/*!******************************************************!*\
  !*** ./src/app/pages/driver/editpic/editpic.page.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditpicPage": () => (/* binding */ EditpicPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_editpic_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./editpic.page.html */ 3122);
/* harmony import */ var _editpic_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editpic.page.scss */ 6616);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/database.service */ 4382);






let EditpicPage = class EditpicPage {
    constructor(dbs, popoverController) {
        this.dbs = dbs;
        this.popoverController = popoverController;
    }
    ngOnInit() {
    }
    updatePic(event) {
        this.dbs.updatePic(event.target.files[0]);
        this.popoverController.dismiss();
    }
};
EditpicPage.ctorParameters = () => [
    { type: src_app_services_database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.PopoverController }
];
EditpicPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-editpic',
        template: _raw_loader_editpic_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_editpic_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EditpicPage);



/***/ }),

/***/ 5653:
/*!************************************************************!*\
  !*** ./src/app/pages/driver/menudriver/menudriver.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenudriverPage": () => (/* binding */ MenudriverPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_menudriver_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./menudriver.page.html */ 3670);
/* harmony import */ var _menudriver_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menudriver.page.scss */ 1450);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_account_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/account.service */ 9876);
/* harmony import */ var src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/database.service */ 4382);
/* harmony import */ var _editpic_editpic_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../editpic/editpic.page */ 8455);










let MenudriverPage = class MenudriverPage {
    constructor(modalController, menu, router, dbs, acs, afa, popoverController) {
        this.modalController = modalController;
        this.menu = menu;
        this.router = router;
        this.dbs = dbs;
        this.acs = acs;
        this.afa = afa;
        this.popoverController = popoverController;
    }
    ngOnInit() {
    }
    toggle() {
        this.menu.toggle();
    }
    navigate(route) {
        this.menu.toggle();
        this.router.navigateByUrl("menudriver/" + route);
    }
    signout() {
        this.menu.toggle();
        this.afa.signOut().then(res => {
            this.acs.loginStatus = false;
            this.router.navigateByUrl("menudriver");
        });
    }
    edit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _editpic_editpic_page__WEBPACK_IMPORTED_MODULE_4__.EditpicPage,
                cssClass: 'my-custom-class',
                translucent: true
            });
            yield popover.present();
        });
    }
};
MenudriverPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__.DatabaseService },
    { type: src_app_services_account_service__WEBPACK_IMPORTED_MODULE_2__.AccountService },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_8__.AngularFireAuth },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.PopoverController }
];
MenudriverPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-menudriver',
        template: _raw_loader_menudriver_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_menudriver_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MenudriverPage);



/***/ }),

/***/ 5957:
/*!***********************************************!*\
  !*** ./src/app/pages/editpic/editpic.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditpicPage": () => (/* binding */ EditpicPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_editpic_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./editpic.page.html */ 4679);
/* harmony import */ var _editpic_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editpic.page.scss */ 1949);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/database.service */ 4382);






let EditpicPage = class EditpicPage {
    constructor(dbs, popoverController) {
        this.dbs = dbs;
        this.popoverController = popoverController;
    }
    ngOnInit() {
    }
    updatePic(event) {
        this.dbs.updatePic(event.target.files[0]);
        this.popoverController.dismiss();
    }
};
EditpicPage.ctorParameters = () => [
    { type: src_app_services_database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.PopoverController }
];
EditpicPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-editpic',
        template: _raw_loader_editpic_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_editpic_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EditpicPage);



/***/ }),

/***/ 678:
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home.page.html */ 8102);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 7603);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _searchbus_searchbus_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../searchbus/searchbus.page */ 5942);
/* harmony import */ var src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/database.service */ 4382);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);








let HomePage = class HomePage {
    constructor(modalController, dbs, router) {
        this.modalController = modalController;
        this.dbs = dbs;
        this.router = router;
        this.slots = [];
    }
    ngOnInit() {
    }
    searchbus() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _searchbus_searchbus_page__WEBPACK_IMPORTED_MODULE_2__.SearchbusPage,
            });
            return yield modal.present();
        });
    }
    book(slot) {
        this.dbs.book(slot.id);
    }
    navigate() {
        this.router.navigateByUrl("");
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__.DatabaseService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], HomePage);



/***/ }),

/***/ 7506:
/*!*****************************************!*\
  !*** ./src/app/pages/menu/menu.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuPage": () => (/* binding */ MenuPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_menu_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./menu.page.html */ 538);
/* harmony import */ var _menu_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu.page.scss */ 6954);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_account_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/account.service */ 9876);
/* harmony import */ var src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/database.service */ 4382);
/* harmony import */ var _editpic_editpic_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../editpic/editpic.page */ 5957);












let MenuPage = class MenuPage {
    constructor(modalController, menu, router, dbs, acs, afa, popoverController) {
        this.modalController = modalController;
        this.menu = menu;
        this.router = router;
        this.dbs = dbs;
        this.acs = acs;
        this.afa = afa;
        this.popoverController = popoverController;
        this.defaultPic = "../../../assets/profile.png";
    }
    ngOnInit() {
        this.dbs.getSlots();
    }
    toggle() {
        this.menu.toggle();
    }
    navigate(route) {
        this.menu.toggle();
        if (route == "")
            this.router.navigateByUrl("menu");
        else
            this.router.navigateByUrl("menu/" + route);
    }
    signout() {
        this.afa.signOut().then(res => {
            this.acs.loginStatus = false;
            this.router.navigateByUrl("menu");
            this.dbs.bookings = [];
            this.menu.toggle();
        });
    }
    edit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _editpic_editpic_page__WEBPACK_IMPORTED_MODULE_4__.EditpicPage,
                cssClass: 'my-custom-class',
                translucent: true
            });
            yield popover.present();
        });
    }
};
MenuPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__.DatabaseService },
    { type: src_app_services_account_service__WEBPACK_IMPORTED_MODULE_2__.AccountService },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_8__.AngularFireAuth },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.PopoverController }
];
MenuPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-menu',
        template: _raw_loader_menu_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_menu_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MenuPage);



/***/ }),

/***/ 5942:
/*!***************************************************!*\
  !*** ./src/app/pages/searchbus/searchbus.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchbusPage": () => (/* binding */ SearchbusPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_searchbus_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./searchbus.page.html */ 9662);
/* harmony import */ var _searchbus_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./searchbus.page.scss */ 5036);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/database.service */ 4382);






let SearchbusPage = class SearchbusPage {
    constructor(modalController, dbs) {
        this.modalController = modalController;
        this.dbs = dbs;
    }
    ngOnInit() {
        this.slots = this.dbs.slots;
    }
    dismiss() {
        this.modalController.dismiss();
    }
    searchBus() {
        let datetime = new Date(this.date);
        if (this.source != undefined && this.destination != undefined && this.date != undefined && this.time != undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.from == this.source && slot.to == this.destination
                && slot.date.toLocaleDateString() == datetime.toLocaleDateString() &&
                ((slot.date.getHours().toString() + ":" + slot.date.getMinutes().toString()) == this.time));
        }
        else if (this.source != undefined && this.destination != undefined && this.date != undefined && this.time == undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.from == this.source && slot.to == this.destination
                && slot.date.toLocaleDateString() == datetime.toLocaleDateString());
        }
        else if (this.source == undefined && this.destination != undefined && this.date == undefined && this.time == undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.to == this.destination);
        }
        else if (this.source != undefined && this.destination == undefined && this.date == undefined && this.time == undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.from == this.source);
        }
        else if (this.source == undefined && this.destination != undefined && this.date != undefined && this.time != undefined) {
            console.log(datetime);
            console.log(this.time);
            this.slots = this.dbs.slots.
                filter(slot => slot.to == this.destination && slot.date.toLocaleDateString() == datetime.toLocaleDateString()
                && ((slot.date.getHours().toString() + ":" + slot.date.getMinutes().toString()) == this.time));
        }
        else if (this.source == undefined && this.destination == undefined && this.date != undefined && this.time != undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.date.toLocaleDateString() == datetime.toLocaleDateString() &&
                ((slot.date.getHours().toString() + ":" + slot.date.getMinutes().toString()) == this.time));
        }
        else if (this.source == undefined && this.destination == undefined && this.date == undefined && this.time != undefined) {
            this.slots = this.dbs.slots.
                filter(slot => ((slot.date.getHours().toString() + ":" + slot.date.getMinutes().toString()) == this.time));
        }
        else if (this.source == undefined && this.destination != undefined && this.date != undefined && this.time == undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.to == this.destination
                && slot.date.toLocaleDateString() == datetime.toLocaleDateString());
        }
        else if (this.source == undefined && this.destination == undefined && this.date != undefined && this.time == undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.date.toLocaleDateString() == datetime.toLocaleDateString());
        }
        else if (this.source != undefined && this.destination != undefined && this.date == undefined && this.time == undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.from == this.source && slot.to == this.destination);
        }
        else if (this.source != undefined && this.destination == undefined && this.date == undefined && this.time != undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.from == this.source &&
                ((slot.date.getHours().toString() + ":" + slot.date.getMinutes().toString()) == this.time));
        }
        else if (this.source != undefined && this.destination == undefined && this.date != undefined && this.time == undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.from == this.source &&
                slot.date.toLocaleDateString() == datetime.toLocaleDateString());
        }
        else if (this.source != undefined && this.destination == undefined && this.date != undefined && this.time != undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.from == this.source &&
                slot.date.toLocaleDateString() == datetime.toLocaleDateString() &&
                ((slot.date.getHours().toString() + ":" + slot.date.getMinutes().toString()) == this.time));
        }
        if (this.source == undefined && this.destination != undefined && this.date == undefined && this.time != undefined) {
            this.slots = this.dbs.slots.
                filter(slot => slot.to == this.destination &&
                ((slot.date.getHours().toString() + ":" + slot.date.getMinutes().toString()) == this.time));
        }
    }
};
SearchbusPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController },
    { type: src_app_services_database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService }
];
SearchbusPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-searchbus',
        template: _raw_loader_searchbus_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_searchbus_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SearchbusPage);



/***/ }),

/***/ 2590:
/*!*********************************************!*\
  !*** ./src/app/pages/signin/signin.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SigninPage": () => (/* binding */ SigninPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_signin_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./signin.page.html */ 2269);
/* harmony import */ var _signin_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signin.page.scss */ 9362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);






let SigninPage = class SigninPage {
    constructor(router, auth) {
        this.router = router;
        this.auth = auth;
        this.clicked = false;
    }
    ngOnInit() {
    }
    navigate() {
        this.router.navigateByUrl("menu/signup");
    }
    signin() {
        this.auth.signIn(this.email, this.password);
    }
};
SigninPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
SigninPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-signin',
        template: _raw_loader_signin_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_signin_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SigninPage);



/***/ }),

/***/ 4374:
/*!*********************************************!*\
  !*** ./src/app/pages/signup/signup.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyErrorStateMatcher": () => (/* binding */ MyErrorStateMatcher),
/* harmony export */   "SignupPage": () => (/* binding */ SignupPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_signup_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./signup.page.html */ 1979);
/* harmony import */ var _signup_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signup.page.scss */ 9233);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);







class MyErrorStateMatcher {
    isErrorState(control, form) {
        const isSubmitted = form && form.submitted;
        return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
    }
}
let SignupPage = class SignupPage {
    constructor(router, auth) {
        this.router = router;
        this.auth = auth;
        this.matcher = new MyErrorStateMatcher();
        this.fenabled = false;
        this.lenabled = false;
        this.stenabled = false;
        this.emenabled = false;
        this.passenabled = false;
        this.hasCode = false;
    }
    ngOnInit() {
        this.signupForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder().group({
            firstname: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern('[a-zA-Z ]*')]],
            lastname: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern('[a-zA-Z ]*')]],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.email, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]],
            studentNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.maxLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern("^[0-9]{9}$")]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&].{8,}')]],
            cpassword: [''],
        });
    }
    get firstname() { return this.signupForm.get('firstname'); }
    get lastname() { return this.signupForm.get('lastname'); }
    get email() { return this.signupForm.get('email'); }
    get studentNumber() { return this.signupForm.get('studentNumber'); }
    get password() { return this.signupForm.get('password'); }
    get cpassword() { return this.signupForm.get('cpassword'); }
    navigate() {
        this.router.navigateByUrl("menu/signin");
    }
    signup() {
        if (this.signupForm.value["password"] == this.signupForm.value["cpassword"]) {
            this.auth.signup(this.signupForm.value["firstname"], this.signupForm.value["lastname"], this.signupForm.value["studentNumber"], this.signupForm.value["email"], this.signupForm.value["password"]);
        }
        else {
            alert("Password do not match");
        }
    }
    fnameEnable() {
        this.fenabled = true;
    }
    lnameEnable() {
        this.lenabled = true;
    }
    phoneEnable() {
        this.stenabled = true;
    }
    emailEnable() {
        this.emenabled = true;
    }
    passEnable() {
        this.passenabled = true;
    }
    keydown() {
        console.log(String(this.signupForm.value["phone"]).length);
        if (String(this.signupForm.value["phone"]).length == 3)
            this.hasCode = String(this.signupForm.value["phone"]).substring(0, 3) == "+27" ? true : false;
        console.log(this.hasCode);
    }
};
SignupPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
SignupPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-signup',
        template: _raw_loader_signup_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_signup_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SignupPage);



/***/ }),

/***/ 9876:
/*!*********************************************!*\
  !*** ./src/app/services/account.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountService": () => (/* binding */ AccountService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);


let AccountService = class AccountService {
    constructor() {
        this.loginStatus = false;
    }
};
AccountService.ctorParameters = () => [];
AccountService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], AccountService);



/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _account_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account.service */ 9876);
/* harmony import */ var _modells_student_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../modells/student.model */ 8244);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./database.service */ 4382);
/* harmony import */ var _modells_driver_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../modells/driver.model */ 7751);
/* harmony import */ var _modells_slot_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../modells/slot.model */ 6610);
/* harmony import */ var _modells_booking_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../modells/booking.model */ 3652);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);












let AuthService = class AuthService {
    constructor(afa, afs, acs, router, dbs, alertController) {
        this.afa = afa;
        this.afs = afs;
        this.acs = acs;
        this.router = router;
        this.dbs = dbs;
        this.alertController = alertController;
        this.slots = [];
        this.bookingsDriver = [];
        this.clicked = false;
    }
    signIn(email, password) {
        this.clicked = true;
        this.afa.signInWithEmailAndPassword(email, password)
            .then(res => {
            this.afs.collection("Student").doc(res.user.uid).valueChanges().subscribe(data => {
                this.acs.user = new _modells_student_model__WEBPACK_IMPORTED_MODULE_1__.Student(res.user.uid, data["firstname"], data["lastname"], data["studentNumber"], data["email"], data["imgURL"]);
                this.dbs.getBookings();
                this.acs.loginStatus = true;
                this.clicked = false;
                this.router.navigateByUrl("menu");
            });
        }).catch(error => {
            this.clicked = false;
            alert(error.message);
        });
    }
    signInDriver(email, password) {
        this.afa.signInWithEmailAndPassword("makwale.em@gmail.com", "Manuelmame35@")
            .then(res => {
            this.afs.collection("Driver").doc("XHZyrLkGPua33C6x48jiTqx1Re03").valueChanges().subscribe(data => {
                if (data != undefined) {
                    this.acs.user = new _modells_driver_model__WEBPACK_IMPORTED_MODULE_3__.Driver(res.user.uid, data["firstname"], data["lastname"], data["phone"], data["email"], data["imgURL"]);
                    this.getSlotsDriver(res.user.uid);
                    this.acs.loginStatus = true;
                    this.router.navigateByUrl("menudriver/home");
                }
                else {
                    alert("Unauthorised user");
                }
            });
        }).catch(error => {
            alert(error.message);
        });
    }
    signup(name, surname, studn, email, password) {
        this.afa.createUserWithEmailAndPassword(email, password).then(userCredentials => {
            let id = userCredentials.user.uid;
            this.afs.collection("Student").doc(id).set({
                firstname: name,
                lastname: surname,
                studentNumber: studn,
                email: email,
                imgURL: ""
            }).then(res => {
                this.router.navigateByUrl("menu/signin");
            }).catch(error => {
                alert(error.message);
            });
        }).catch(error => {
            alert(error.message);
        });
    }
    getSlotsDriver(id) {
        this.afs.collection("Bus", ref => ref.where("driverid", "==", id)).snapshotChanges().
            subscribe(data => {
            this.afs.collection("Slot", ref => ref.where("busid", "==", data[0].payload.doc.id)).snapshotChanges().
                subscribe(data => {
                for (let slotdata of data) {
                    let slot = new _modells_slot_model__WEBPACK_IMPORTED_MODULE_4__.Slot(slotdata.payload.doc.id, slotdata.payload.doc.data()["date"], slotdata.payload.doc.data()["busid"], slotdata.payload.doc.data()["geo"], slotdata.payload.doc.data()["avail"], slotdata.payload.doc.data()["booked"], slotdata.payload.doc.data()["from"], slotdata.payload.doc.data()["to"]);
                    if (!this.searchSlot(slot)) {
                        this.slots.push(slot);
                        this.getBookingsSlot(slot);
                    }
                }
            });
        });
    }
    searchSlot(tempSlot) {
        for (let slot of this.slots) {
            if (slot.id == tempSlot.id)
                return true;
        }
        return false;
    }
    getBookingsSlot(slot) {
        this.afs.collection("Booking", ref => ref.where("slotid", "==", slot.id)).snapshotChanges().
            subscribe(data => {
            for (let bdata of data) {
                this.bookingsDriver.push(new _modells_booking_model__WEBPACK_IMPORTED_MODULE_5__.Booking(bdata.payload.doc.id, slot, bdata.payload.doc.data()["studentid"]));
            }
        });
    }
    checkStudentIn(slotId, studentNumber) {
        this.afs.collection("Student", ref => ref.where("studentNumber", "==", studentNumber)).snapshotChanges().
            subscribe(data => {
            if (data.length > 0) {
                if (this.searchStudentBooking(slotId, data[0].payload.doc.id)) {
                    alert("Checked in " + String(studentNumber));
                }
                else {
                    alert("Student not found for this slot " + String(studentNumber));
                }
            }
            else {
                alert("Student does not exists " + String(studentNumber));
            }
        });
    }
    searchStudentBooking(slotId, studentNumber) {
        for (let booking of this.bookingsDriver) {
            if (booking.studentId == studentNumber && booking.slot.id == slotId) {
                this.afs.collection("Booking").doc(booking.id).update({
                    checkedin: true
                });
                return true;
            }
        }
        return false;
    }
    updateGeoSlot(id) {
        this.trackingSlotId = id;
        this.afs.collection("Slot").doc(id).update({
            gps: true
        }).then(() => {
            alert("Bus GPS enabled");
        });
        navigator.geolocation.watchPosition(pos => {
            this.afs.collection("Slot").doc(this.trackingSlotId).update({
                geo: [pos.coords.longitude, pos.coords.latitude]
            });
        });
    }
    updateInfor(name, surname, phone) {
        this.afs.collection("Driver").doc(this.acs.user.id).update({
            firstname: name,
            lastname: surname,
            phone: phone
        }).then(() => {
            this.acs.user.lastname = name;
            this.acs.user.lastname = surname;
            this.acs.user.phone = phone;
            alert("Profile updated");
        }).catch(err => {
            alert(err.message);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_6__.AngularFireAuth },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__.AngularFirestore },
    { type: _account_service__WEBPACK_IMPORTED_MODULE_0__.AccountService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 4382:
/*!**********************************************!*\
  !*** ./src/app/services/database.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatabaseService": () => (/* binding */ DatabaseService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/storage */ 8274);
/* harmony import */ var _modells_booking_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../modells/booking.model */ 3652);
/* harmony import */ var _modells_slot_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../modells/slot.model */ 6610);
/* harmony import */ var _account_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./account.service */ 9876);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 8939);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 9895);










let DatabaseService = class DatabaseService {
    constructor(afs, popoverController, acs, storage, router) {
        this.afs = afs;
        this.popoverController = popoverController;
        this.acs = acs;
        this.storage = storage;
        this.router = router;
        this.slots = [];
        this.slotsDriver = [];
        this.bookings = [];
        this.tempbooking = [];
        this.isSlotUpdated = false;
        this.isBookingUpdated = false;
        this.couterGetBooking = 0;
    }
    getSlots() {
        this.afs.collection("Slot").snapshotChanges().subscribe(data => {
            this.slots = [];
            for (let slotd of data) {
                let slotid = slotd.payload.doc.id;
                let slotdata = slotd.payload.doc.data();
                let slot = new _modells_slot_model__WEBPACK_IMPORTED_MODULE_1__.Slot(slotid, slotdata["date"], slotdata["busid"], slotdata["geo"], slotdata["avail"], slotdata["booked"], slotdata["from"], slotdata["to"]);
                if (!this.searchSlot(slot))
                    this.slots.push(slot);
            }
        });
    }
    searchSlot(tempSlot) {
        for (let slot of this.slots) {
            if (slot.id == tempSlot.id)
                return true;
        }
        return false;
    }
    book(slotId) {
        console.log(this.bookings);
        if (!this.preventDuplicates(slotId)) {
            if (!this.isStudentBookedBefore(slotId, this.acs.user.id)) {
                this.afs.collection("Booking").add({
                    slotid: slotId,
                    studentid: this.acs.user.id
                }).then(res => {
                    alert("Booked");
                    this.updateSlotBooking(slotId);
                }).catch(error => {
                    alert("Something wrong happened");
                });
            }
            else {
                this.updateSlotBooking(slotId);
            }
        }
        else {
            alert("You already booked");
        }
    }
    getBookings() {
        console.log(this.couterGetBooking);
        this.afs.collection("Booking", ref => ref.where("studentid", "==", this.acs.user.id)).snapshotChanges().subscribe(data => {
            for (let booking of data) {
                let bookingId = booking.payload.doc.id;
                let bookingData = booking.payload.doc.data();
                this.afs.collection("Slot").doc(bookingData["slotid"]).snapshotChanges().subscribe(data => {
                    let slotid = data.payload.id;
                    let slotdata = data.payload.data();
                    let slot = new _modells_slot_model__WEBPACK_IMPORTED_MODULE_1__.Slot(slotid, slotdata["date"], slotdata["busid"], slotdata["geo"], slotdata["avail"], slotdata["booked"], slotdata["from"], slotdata["to"]);
                    let booking = new _modells_booking_model__WEBPACK_IMPORTED_MODULE_0__.Booking(bookingId, slot, this.acs.user.id, bookingData["cancelled"]);
                    if (!this.searchBooking(booking)) {
                        if (!booking.cancelled) {
                            if (this.couterGetBooking == 0) {
                                this.bookings.push(booking);
                                this.tempbooking.push(booking);
                            }
                        }
                    }
                });
            }
        });
    }
    isStudentBookedBefore(slotid, studid) {
        for (let booking of this.tempbooking) {
            if (booking.slot.id == slotid && booking.studentId == studid) {
                this.afs.collection("Booking").doc(booking.id).update({
                    cancelled: false
                });
                alert("Booked");
                return true;
            }
        }
        return false;
    }
    preventDuplicates(id) {
        for (let booking of this.bookings) {
            if (booking.slot.id == id) {
                return true;
            }
        }
        return false;
    }
    updateSlotBooking(id) {
        for (let slot of this.slots) {
            if (slot.id == id) {
                let avails = slot.availableSeats - 1;
                let bookeds = slot.bookedSeats + 1;
                this.afs.collection("Slot").doc(id).update({
                    avail: avails,
                    booked: bookeds
                }).then(res => {
                    alert("Updated");
                }).catch(error => {
                    alert("Something went wrong");
                });
            }
        }
    }
    updateSlotCancelation(booking) {
        for (let slot of this.slots) {
            if (slot.id == booking.slot.id) {
                let avails = slot.availableSeats + 1;
                let bookeds = slot.bookedSeats - 1;
                this.afs.collection("Slot").doc(slot.id).update({
                    avail: avails,
                    booked: bookeds
                }).then(res => {
                    alert("Booking Cancelled");
                    for (let i = 0; i < this.bookings.length; i++) {
                        console.log(this.bookings[i]);
                        if (this.bookings[i].id == booking.id) {
                            this.bookings[i].cancelled = true;
                            this.bookings.splice(i, 1);
                            console.log(this.bookings[i]);
                        }
                    }
                    console.log(this.bookings);
                }).catch(error => {
                    alert("Something went wrong");
                });
            }
        }
    }
    searchBooking(tempBooking) {
        for (let booking of this.bookings) {
            if (booking.id == tempBooking.id)
                return true;
        }
        return false;
    }
    getSlotGeo(id) {
        return this.afs.collection("Slot").doc(id);
    }
    cancel(booking) {
        this.afs.collection("Booking").doc(booking.id).update({
            cancelled: true
        }).then(() => {
            this.updateSlotCancelation(booking);
        }).catch(error => {
            alert("Something wrong happened");
        });
    }
    updateInfor(name, surname, sn) {
        this.afs.collection("Student").doc(this.acs.user.id).update({
            firstname: name,
            lastname: surname,
            studentNumber: sn
        }).then(() => {
            this.acs.user.lastname = name;
            this.acs.user.lastname = surname;
            this.acs.user.studentNumber = sn;
            alert("Profile updated");
        });
    }
    updatePic(file) {
        const filePath = this.acs.user.id;
        const ref = this.storage.ref("StudentProfile/" + filePath);
        const task = ref.put(file);
        task.snapshotChanges().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.finalize)(() => {
            ref.getDownloadURL().subscribe(url => {
                this.afs.collection("Student").doc(this.acs.user.id).update({
                    imgURL: url,
                }).then(() => {
                    this.popoverController.dismiss();
                    alert("Profile picture updated");
                }).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
                    alert(error.message);
                }));
            });
        })).subscribe();
    }
};
DatabaseService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_5__.AngularFirestore },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.PopoverController },
    { type: _account_service__WEBPACK_IMPORTED_MODULE_2__.AccountService },
    { type: _angular_fire_storage__WEBPACK_IMPORTED_MODULE_7__.AngularFireStorage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router }
];
DatabaseService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Injectable)({
        providedIn: 'root'
    })
], DatabaseService);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 4608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		7321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		6108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		1489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		305,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		5830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		7757,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		392,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		6911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		937,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		8695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		2239,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		8837,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		4195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		1709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		5931,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		4513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		8056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		6272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		1855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		8708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		3527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		4694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		9222,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		9921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		3584,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		1602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5174,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		6164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		7162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		7896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		5043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		7802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		9072,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		2191,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		801,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		7110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 3069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 6616:
/*!********************************************************!*\
  !*** ./src/app/pages/driver/editpic/editpic.page.scss ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0cGljLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 1450:
/*!**************************************************************!*\
  !*** ./src/app/pages/driver/menudriver/menudriver.page.scss ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZW51ZHJpdmVyLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 1949:
/*!*************************************************!*\
  !*** ./src/app/pages/editpic/editpic.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0cGljLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 7603:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFFQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFBRjs7QUFHQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUVBLGNBQUE7RUFFQSxTQUFBO0FBRkY7O0FBS0E7RUFDRSxxQkFBQTtBQUZGIiwiZmlsZSI6ImhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2NvbnRhaW5lciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICB0b3A6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xufVxuXG4jY29udGFpbmVyIHN0cm9uZyB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGluZS1oZWlnaHQ6IDI2cHg7XG59XG5cbiNjb250YWluZXIgcCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG5cbiAgY29sb3I6ICM4YzhjOGM7XG5cbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59Il19 */");

/***/ }),

/***/ 6954:
/*!*******************************************!*\
  !*** ./src/app/pages/menu/menu.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZW51LnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 5036:
/*!*****************************************************!*\
  !*** ./src/app/pages/searchbus/searchbus.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZWFyY2hidXMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 9362:
/*!***********************************************!*\
  !*** ./src/app/pages/signin/signin.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzaWduaW4ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 9233:
/*!***********************************************!*\
  !*** ./src/app/pages/signup/signup.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzaWdudXAucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 1106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ 3122:
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/driver/editpic/editpic.page.html ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-input  type=\"file\"  accept=\"image/*\" (change)=\"updatePic($event)\"></ion-input>\n");

/***/ }),

/***/ 3670:
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/driver/menudriver/menudriver.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Dashboard</ion-title>\n\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"acs.loginStatus\" (click)=\"toggle()\"><ion-icon size=\"large\" color=\"ourtheme\" name=\"menu-outline\"></ion-icon></ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  \n  <ion-menu side=\"start\" menuId=\"menu\" contentId=\"main\">\n  \n      <ion-header *ngIf=\"acs.loginStatus\">\n        <ion-toolbar color=\"ourtheme\">\n          <h4 style=\"text-align: center; margin-top: 15px; font-weight: 500;letter-spacing: 1px;\">Welcome Back {{acs.user.firstname}}</h4>\n          \n        </ion-toolbar>\n      </ion-header>\n    \n    <ion-content>\n      <ion-list>\n        <ion-item *ngIf=\"acs.loginStatus\" (click)=\"navigate('home')\" ><ion-icon color=\"ourtheme\" slot=\"start\" name=\"home-outline\"></ion-icon>Home</ion-item>\n        \n        <ion-item *ngIf=\"acs.loginStatus\" (click)=\"navigate('account')\" ><ion-icon color=\"ourtheme\" slot=\"start\" name=\"person-outline\"></ion-icon>Account</ion-item>\n                        \n        <ion-item *ngIf=\"acs.loginStatus\" (click)=\"signout()\" ><ion-icon slot=\"start\" color=\"ourtheme\" name=\"log-out-outline\"></ion-icon>Signout</ion-item>\n        \n      </ion-list>\n    </ion-content>\n  </ion-menu>\n  \n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n</ion-content>\n");

/***/ }),

/***/ 4679:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/editpic/editpic.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-input  type=\"file\"  accept=\"image/*\" (change)=\"updatePic($event)\"></ion-input>\n");

/***/ }),

/***/ 8102:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"ourtheme\">\n\n    <ion-title>\n      Home\n    </ion-title>\n\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"navigate()\">Back</ion-button>\n    </ion-buttons>\n    \n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-searchbar (click)=\"searchbus()\" style=\"position: fixed; z-index: 100;\" placeholder=\"Search by source or destination\" ></ion-searchbar>\n\n  <div style=\"margin-top: 60px;\"></div>\n\n  <ion-card *ngFor=\"let slot of dbs.slots\" >\n   \n      \n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"5\">\n          <ion-label>From: {{slot.from}}</ion-label>\n        </ion-col>\n        <ion-col size=\"2\">\n          <ion-icon size=\"medium\" name=\"swap-horizontal-outline\"></ion-icon>\n        </ion-col>\n  \n        <ion-col size=\"5\">\n          <ion-label>To: {{slot.to}}</ion-label>\n        </ion-col>\n      </ion-row>\n  \n      <ion-row>\n        <ion-col size=\"5\">\n          <ion-label>Date: {{slot.date | date: 'mediumDate'}}</ion-label>\n        </ion-col>\n        <ion-col size=\"2\">\n            \n        </ion-col>\n  \n        <ion-col size=\"5\">\n          <ion-label>Time: {{slot.date | date: 'shortTime'}}</ion-label>\n        </ion-col>\n      </ion-row>\n  \n      <ion-row>\n        <ion-col size=\"5\">\n          <ion-label>Seats Avail: {{slot.availableSeats}}</ion-label>\n        </ion-col>\n        <ion-col size=\"2\">\n           \n        </ion-col>\n  \n        <ion-col size=\"5\">\n          <ion-label>Seats Booked: {{slot.bookedSeats}}</ion-label>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n    <ion-button size=\"small\" color=\"ourtheme\" expand=\"full\" (click)=\"book(slot)\">Book</ion-button>\n  </ion-card>\n\n  \n</ion-content>\n");

/***/ }),

/***/ 538:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/menu/menu.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-avatar>\n      <img style=\"margin-left: 10px;\" src=\"../../../assets/bus.png\">\n    </ion-avatar>\n\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"toggle()\"><ion-icon size=\"large\" color=\"ourtheme\" name=\"menu-outline\"></ion-icon></ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  \n  <ion-menu side=\"start\" menuId=\"menu\" contentId=\"main\">\n    <ion-header *ngIf=\"acs.loginStatus\">\n      <ion-toolbar color=\"ourtheme\">\n        <h4 style=\"text-align: center; margin-top: 15px; font-weight: 500;letter-spacing: 1px;\">Welcome Back {{acs.user.firstname}}</h4>\n        \n      </ion-toolbar>\n    </ion-header>\n  \n    <div *ngIf=\"acs.loginStatus\" style=\"text-align: center;\">\n      <ion-avatar style=\"height: 150px; width: 150px; margin: auto; margin-top: 10px;\">\n        <img *ngIf=\"acs.user.imgURL == ''\" [src]=\"defaultPic\">\n        <img *ngIf=\"acs.user.imgURL != ''\" [src]=\"acs.user.imgURL\">\n\n      </ion-avatar>\n      <ion-button color=\"ourtheme\" fill=\"transparent\" style=\"margin: auto;\" (click)=\"edit()\"><ion-icon size=\"large\" color=\"ourtheme\" name=\"camera-outline\"></ion-icon></ion-button>\n      \n    </div>\n    \n    <ion-content>\n      <ion-list>\n        <ion-item (click)=\"navigate('')\" ><ion-icon color=\"ourtheme\" slot=\"start\" name=\"home-outline\"></ion-icon><span style=\"color: #0a4694;\">Home</span></ion-item>\n        \n        <ion-item *ngIf=\"acs.loginStatus\" (click)=\"navigate('bookings')\" ><ion-icon color=\"ourtheme\" slot=\"start\" name=\"bookmark-outline\"></ion-icon><span style=\"color: #0a4694;\">Bookings</span></ion-item>\n        \n        <ion-item (click)=\"navigate('map')\"> <ion-icon color=\"ourtheme\" slot=\"start\" name=\"map-outline\"></ion-icon><span style=\"color: #0a4694;\">Map</span></ion-item>\n       \n        <ion-item *ngIf=\"acs.loginStatus\" (click)=\"navigate('account')\" ><ion-icon color=\"ourtheme\" slot=\"start\" name=\"person-outline\"></ion-icon><span style=\"color: #0a4694;\">Account</span></ion-item>\n        \n        <ion-item *ngIf=\"!acs.loginStatus\" (click)=\"navigate('signin')\"><ion-icon color=\"ourtheme\" slot=\"start\" name=\"log-in-outline\"></ion-icon><span style=\"color: #0a4694;\">Signin</span></ion-item>\n        \n        <ion-item *ngIf=\"!acs.loginStatus\" (click)=\"navigate('signup')\"><ion-icon slot=\"start\" color=\"ourtheme\" name=\"person-add-outline\"></ion-icon><span style=\"color: #0a4694;\">Signup</span></ion-item>\n        \n        <ion-item *ngIf=\"acs.loginStatus\" (click)=\"signout()\" ><ion-icon slot=\"start\" color=\"ourtheme\" name=\"log-out-outline\"></ion-icon><span style=\"color: #0a4694;\">Signout</span></ion-item>\n        \n      </ion-list>\n    </ion-content>\n  </ion-menu>\n  \n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n</ion-content>\n");

/***/ }),

/***/ 9662:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/searchbus/searchbus.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"ourtheme\">\n    <ion-title>Search Bus</ion-title>\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"dismiss()\"><ion-icon name=\"arrow-back-outline\"></ion-icon></ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n \n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"6\">\n        <ion-item>\n          <ion-label color=\"ourtheme\" position=\"floating\">From</ion-label>\n          <ion-select [(ngModel)]=\"source\" (ionChange)=\"searchBus()\" cancelText=\"Cancel\" okText=\"Done\">\n            <ion-select-option value=\"Sosh South\">Sosh South</ion-select-option>\n            <ion-select-option value=\"Sosh North\">Sosh North</ion-select-option>\n            <ion-select-option value=\"Pta Main\">Pta Main</ion-select-option>\n            <ion-select-option value=\"Arcadia\">Arcadia</ion-select-option>\n            <ion-select-option value=\"Art\">Art</ion-select-option>\n            <ion-select-option value=\"Garankuwa\">Garankuwa</ion-select-option>\n          </ion-select>\n        </ion-item>\n      \n      </ion-col>\n\n      <ion-col size=\"6\">\n        <ion-item>\n          <ion-label color=\"ourtheme\" position=\"floating\">To</ion-label>\n          <ion-select [(ngModel)]=\"destination\" (ionChange)=\"searchBus()\" cancelText=\"Cancel\" okText=\"Done\">\n            <ion-select-option value=\"Sosh South\">Sosh South</ion-select-option>\n            <ion-select-option value=\"Sosh North\">Sosh North</ion-select-option>\n            <ion-select-option value=\"Pta Main\">Pta Main</ion-select-option>\n            <ion-select-option value=\"Arcadia\">Arcadia</ion-select-option>\n            <ion-select-option value=\"Art\">Art</ion-select-option>\n            <ion-select-option value=\"Garankuwa\">Garankuwa</ion-select-option>\n          </ion-select>\n        </ion-item>\n      \n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"7\">\n          <ion-item>\n            <ion-label color=\"ourtheme\" position=\"floating\">Date</ion-label>\n            <ion-input type=\"date\" (ionChange)=\"searchBus()\" [(ngModel)]=\"date\" ></ion-input>\n          </ion-item>\n\n      </ion-col>\n      <ion-col size=\"5\">\n\n        <ion-item>\n          <ion-label color=\"ourtheme\" position=\"floating\">Time</ion-label>\n          <ion-input (ionChange)=\"searchBus()\" [(ngModel)]=\"time\" type=\"time\"></ion-input>\n        </ion-item>\n\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-card *ngFor=\"let slot of slots\" >\n   \n      \n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"5\">\n          <ion-label>From: {{slot.from}}</ion-label>\n        </ion-col>\n        <ion-col size=\"2\">\n          <ion-icon size=\"medium\" name=\"swap-horizontal-outline\"></ion-icon>\n        </ion-col>\n  \n        <ion-col size=\"5\">\n          <ion-label>To: {{slot.to}}</ion-label>\n        </ion-col>\n      </ion-row>\n  \n      <ion-row>\n        <ion-col size=\"5\">\n          <ion-label>Date: {{slot.date | date: 'mediumDate'}}</ion-label>\n        </ion-col>\n        <ion-col size=\"2\">\n            \n        </ion-col>\n  \n        <ion-col size=\"5\">\n          <ion-label>Time: {{slot.date | date: 'shortTime'}}</ion-label>\n        </ion-col>\n      </ion-row>\n  \n      <ion-row>\n        <ion-col size=\"5\">\n          <ion-label>Seats Avail: {{slot.availableSeats}}</ion-label>\n        </ion-col>\n        <ion-col size=\"2\">\n           \n        </ion-col>\n  \n        <ion-col size=\"5\">\n          <ion-label>Seats Booked: {{slot.bookedSeats}}</ion-label>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n    <ion-button size=\"small\" color=\"ourtheme\" expand=\"full\">Book</ion-button>\n  </ion-card>\n\n\n\n</ion-content>\n");

/***/ }),

/***/ 2269:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/signin/signin.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"ourtheme\">\n    <ion-title>Signin</ion-title>\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" >\n\n  <div style=\"position: fixed;\" >\n    <img src=\"../../../assets/ionic.jpg\">\n    <div style=\"position: absolute; width: 100%; height: 299px; background-color: #0a4694;top: 0%; z-index: 100;\"></div>\n  </div>\n\n  \n  <div style=\"position: absolute; z-index: 150; top: 28%; width: 100%; height: 100%; background-color: white; border-top-left-radius: 10px; border-top-right-radius: 10px;\">\n\n\n  <ion-grid style=\"margin-top: 4%;\">\n    <ion-row>\n      <ion-col size=\"12\" style=\"text-align: center;\">\n        <ion-label>Haven't created an account? </ion-label> <ion-label color=\"ourtheme\" (click)=\"navigate()\">Signup here</ion-label>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-item>\n          <ion-label color=\"ourtheme\" position=\"floating\">Email</ion-label>\n          <ion-input [(ngModel)]=\"email\" type=\"email\" ></ion-input>\n        </ion-item>\n\n        <ion-item>\n          <ion-label color=\"ourtheme\" position=\"floating\">Password</ion-label>\n          <ion-input [(ngModel)]=\"password\" type=\"password\"></ion-input>\n        </ion-item>\n\n        <ion-button (click)=\"signin()\" expand=\"block\" color=\"ourtheme\"><span *ngIf=\"!auth.clicked\">Signin</span><ion-spinner *ngIf=\"auth.clicked\" name=\"bubbles\"></ion-spinner></ion-button>\n        \n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 1979:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/signup/signup.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"ourtheme\">\n    <ion-title>Signup</ion-title>\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div style=\"position: fixed;\" >\n    <img src=\"../../../assets/ionic.jpg\">\n    <div style=\"position: absolute; width: 100%; height: 299px; background-color: #0a4694;top: 0%; z-index: 100;\"></div>\n  </div>\n\n  <div style=\"position: absolute; z-index: 150; top: 20%; width: 100%; background-color: white; border-top-left-radius: 10px; border-top-right-radius: 10px;\">\n\n    <div style=\"text-align: center; margin-top: 20px;\">\n      <ion-label>Already have an account? </ion-label> <ion-label color=\"ourtheme\" (click)=\"navigate()\">Signin here</ion-label>\n  \n    </div>\n    \n    <form [formGroup]=\"signupForm\">\n      <ion-item>\n        <ion-label color=\"ourtheme\" position=\"floating\">First Name</ion-label>\n        <ion-input  (ionInput)=\"fnameEnable()\" formControlName=\"firstname\" required enterkeyhint=\"next\" ></ion-input>\n      \n      </ion-item>\n  \n      <div *ngIf=\"fenabled\">\n     \n        <mat-error *ngIf=\"firstname.hasError('required') \">\n          <small style=\"color: red; margin-left: 5px;\">First name is <strong><span style=\"letter-spacing: .5px;\">required</span></strong></small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"firstname.hasError('pattern')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>First name must not have a special charector or a number</small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"firstname.hasError('minlength')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>First name must have atleast 3 letters</small>\n        </mat-error>\n      </div>\n       \n  \n      <ion-item>\n        <ion-label color=\"ourtheme\" position=\"floating\">Last Name</ion-label>\n        <ion-input  (ionInput)=\"lnameEnable()\" formControlName=\"lastname\" enterkeyhint=\"next\"></ion-input>\n      </ion-item>\n  \n      <div *ngIf=\"lenabled\">\n     \n        <mat-error *ngIf=\"lastname.hasError('required') \">\n          <small style=\"color: red; margin-left: 5px;\">Last name is <strong><span style=\"letter-spacing: .5px;\">required</span></strong></small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"lastname.hasError('pattern')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>Last name must not have a special charector or a number</small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"lastname.hasError('minlength')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>Last name must have atleast 3 letters</small>\n        </mat-error>\n      </div>\n    \n      <ion-item>\n        <ion-label color=\"ourtheme\" position=\"floating\">Student Number</ion-label>\n        <ion-input  (ionInput)=\"phoneEnable()\" formControlName=\"studentNumber\" type=\"number\" max=\"9\" enterkeyhint=\"next\">\n    \n        </ion-input>\n        \n      </ion-item>\n  \n      <div *ngIf=\"stenabled\">\n  \n        <mat-error *ngIf=\"studentNumber.hasError('required')\">\n          <small errors style=\"color: red; margin-left: 5px;\" errors>Student number is <strong><span style=\"letter-spacing: .5px;\">required</span></strong></small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"studentNumber.hasError('minlength')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>Student number must have 9 digits</small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"studentNumber.hasError('maxlength')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>Student number must have 9 digits</small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"studentNumber.hasError('pattern')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>Student number must have 9 digits</small>\n        </mat-error>\n  \n      </div>\n    \n      <ion-item>\n        <ion-label color=\"ourtheme\" position=\"floating\">Email</ion-label>\n        <ion-input type=\"password\" (ionInput)=\"emailEnable()\" formControlName=\"email\" type=\"email\" enterkeyhint=\"next\"></ion-input>\n      </ion-item>\n  \n      <div *ngIf=\"emenabled\">\n     \n        <mat-error *ngIf=\"email.hasError('required') \">\n          <small style=\"color: red; margin-left: 5px;\">Email is <strong><span style=\"letter-spacing: .5px;\">required</span></strong></small>\n        </mat-error>\n        <mat-error *ngIf=\"email.hasError('pattern') \">\n          <small style=\"color: red; margin-left: 5px;\">Invalid email address</small>\n        </mat-error>\n  \n      </div>\n    \n      <ion-item>\n        <ion-label color=\"ourtheme\" position=\"floating\">Password</ion-label>\n        <ion-input type=\"password\" (ionInput)=\"passEnable()\" formControlName=\"password\" enterkeyhint=\"next\"></ion-input>\n      </ion-item>\n  \n      <div *ngIf=\"passenabled\">\n     \n        <mat-error *ngIf=\"password.hasError('required') \">\n          <small style=\"color: red; margin-left: 5px;\">Password is <span style=\"letter-spacing: .5px;\"><strong>required</strong></span></small>\n        </mat-error>\n  \n        <mat-error *ngIf=\"password.hasError('pattern')\">\n          <small style=\"color: red; margin-left: 5px;\" errors>Password must be atleast 8 letters in length, 1 uppercase letter, special charector and a number</small>\n        </mat-error>\n  \n      </div>\n    \n      <ion-item>\n        <ion-label color=\"ourtheme\" position=\"floating\">Confirm Password</ion-label>\n        <ion-input formControlName=\"cpassword\" enterkeyhint=\"done\" type=\"password\"></ion-input>\n      </ion-item>\n  \n    \n    </form>\n  \n    <ion-button (click)=\"signup()\" [disabled]=\"signupForm.status == 'INVALID'\"  expand=\"block\" color=\"ourtheme\">Signup</ion-button>\n  \n  \n\n  </div>\n\n  </ion-content>\n");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map