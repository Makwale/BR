(self["webpackChunkBR"] = self["webpackChunkBR"] || []).push([["src_app_pages_account_account_module_ts"],{

/***/ 7173:
/*!*********************************************************!*\
  !*** ./src/app/pages/account/account-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountPageRoutingModule": () => (/* binding */ AccountPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _account_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account.page */ 9610);




const routes = [
    {
        path: '',
        component: _account_page__WEBPACK_IMPORTED_MODULE_0__.AccountPage
    }
];
let AccountPageRoutingModule = class AccountPageRoutingModule {
};
AccountPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AccountPageRoutingModule);



/***/ }),

/***/ 6868:
/*!*************************************************!*\
  !*** ./src/app/pages/account/account.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountPageModule": () => (/* binding */ AccountPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _account_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account-routing.module */ 7173);
/* harmony import */ var _account_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account.page */ 9610);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/form-field */ 8295);









let AccountPageModule = class AccountPageModule {
};
AccountPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _account_routing_module__WEBPACK_IMPORTED_MODULE_0__.AccountPageRoutingModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_7__.MatInputModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__.MatFormFieldModule
        ],
        declarations: [_account_page__WEBPACK_IMPORTED_MODULE_1__.AccountPage]
    })
], AccountPageModule);



/***/ }),

/***/ 9610:
/*!***********************************************!*\
  !*** ./src/app/pages/account/account.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyErrorStateMatcher": () => (/* binding */ MyErrorStateMatcher),
/* harmony export */   "AccountPage": () => (/* binding */ AccountPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_account_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./account.page.html */ 1232);
/* harmony import */ var _account_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account.page.scss */ 3788);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _editpic_editpic_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../editpic/editpic.page */ 5957);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/database.service */ 4382);
/* harmony import */ var src_app_services_account_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/account.service */ 9876);









class MyErrorStateMatcher {
    isErrorState(control, form) {
        const isSubmitted = form && form.submitted;
        return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
    }
}
let AccountPage = class AccountPage {
    constructor(popoverController, dbs, acs) {
        this.popoverController = popoverController;
        this.dbs = dbs;
        this.acs = acs;
        this.matcher = new MyErrorStateMatcher();
        this.fenabled = false;
        this.lenabled = false;
        this.stenabled = false;
        this.isEditable = false;
        this.editClose = "Edit";
        this.defaultPic = "../../../assets/profile.png";
    }
    ngOnInit() {
        this.signupForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder().group({
            firstname: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('[a-zA-Z ]*')]],
            lastname: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('[a-zA-Z ]*')]],
            studentNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.maxLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern("^[0-9]{9}$")]],
        });
        this.signupForm.controls["firstname"].setValue(this.acs.user.firstname);
        this.signupForm.controls["lastname"].setValue(this.acs.user.lastname);
        this.signupForm.controls["studentNumber"].setValue(this.acs.user.studentNumber);
    }
    get firstname() { return this.signupForm.get('firstname'); }
    get lastname() { return this.signupForm.get('lastname'); }
    get studentNumber() { return this.signupForm.get('studentNumber'); }
    navigate() {
        // this.router.navigateByUrl("menu/signin")
    }
    signup() {
        // this.auth.signup(this.signupForm.value["firstname"], this.signupForm.value["lastname"],
        // this.signupForm.value["phone"], this.signupForm.value["email"], this.signupForm.value["password"])
    }
    fnameEnable() {
        this.fenabled = true;
    }
    lnameEnable() {
        this.lenabled = true;
    }
    phoneEnable() {
        this.stenabled = true;
    }
    edit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _editpic_editpic_page__WEBPACK_IMPORTED_MODULE_2__.EditpicPage,
                cssClass: 'my-custom-class',
                translucent: true
            });
            yield popover.present();
        });
    }
    editInfor() {
        this.isEditable = !this.isEditable;
        this.editClose = this.isEditable ? "Cancel" : "Edit";
    }
    update() {
        this.editClose = "Edit";
        console.log(this.signupForm);
        this.dbs.updateInfor(this.signupForm.value["firstname"], this.signupForm.value["lastname"], this.signupForm.value["studentNumber"]);
    }
};
AccountPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.PopoverController },
    { type: src_app_services_database_service__WEBPACK_IMPORTED_MODULE_3__.DatabaseService },
    { type: src_app_services_account_service__WEBPACK_IMPORTED_MODULE_4__.AccountService }
];
AccountPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-account',
        template: _raw_loader_account_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_account_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AccountPage);



/***/ }),

/***/ 3788:
/*!*************************************************!*\
  !*** ./src/app/pages/account/account.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY2NvdW50LnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 1232:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/account/account.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"ourtheme\">\n    <ion-title>Account</ion-title>\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button>\n     \n      </ion-back-button>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"editInfor()\">\n        {{editClose}}\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n<div style=\"text-align: center;\">\n  <ion-avatar style=\"height: 150px; width: 150px; margin: auto; margin-top: 25px;\">\n    <img *ngIf=\"!acs.user.imgURL\" [src]=\"defaultPic\">\n    <img *ngIf=\"acs.user.imgURL != ''\" [src]=\"acs.user.imgURL\">\n  </ion-avatar>\n  <ion-button color=\"ourtheme\" fill=\"transparent\" style=\"margin: auto;\" (click)=\"edit()\"><ion-icon size=\"large\" color=\"ourtheme\" name=\"camera-outline\"></ion-icon></ion-button>\n      \n</div>\n  \n\n  <form [formGroup]=\"signupForm\">\n    <ion-item>\n      <ion-label color=\"ourtheme\" position=\"floating\">First Name</ion-label>\n      <ion-input [disabled]=\"!isEditable\"  (ionInput)=\"fnameEnable()\" formControlName=\"firstname\" required enterkeyhint=\"next\" ></ion-input>\n    \n    </ion-item>\n\n    <div *ngIf=\"fenabled\">\n   \n      <mat-error *ngIf=\"firstname.hasError('required') \">\n        <small style=\"color: red; margin-left: 5px;\">First name is <strong><span style=\"letter-spacing: .5px;\">required</span></strong></small>\n      </mat-error>\n\n      <mat-error *ngIf=\"firstname.hasError('pattern')\">\n        <small style=\"color: red; margin-left: 5px;\" errors>First name must not have a special charector or a number</small>\n      </mat-error>\n\n      <mat-error *ngIf=\"firstname.hasError('minlength')\">\n        <small style=\"color: red; margin-left: 5px;\" errors>First name must have atleast 3 letters</small>\n      </mat-error>\n    </div>\n     \n\n    <ion-item>\n      <ion-label color=\"ourtheme\" position=\"floating\">Last Name</ion-label>\n      <ion-input [disabled]=\"!isEditable\"  (ionInput)=\"lnameEnable()\" formControlName=\"lastname\" enterkeyhint=\"next\"></ion-input>\n    </ion-item>\n\n    <div *ngIf=\"lenabled\">\n   \n      <mat-error *ngIf=\"lastname.hasError('required') \">\n        <small style=\"color: red; margin-left: 5px;\">Last name is <strong><span style=\"letter-spacing: .5px;\">required</span></strong></small>\n      </mat-error>\n\n      <mat-error *ngIf=\"lastname.hasError('pattern')\">\n        <small style=\"color: red; margin-left: 5px;\" errors>Last name must not have a special charector or a number</small>\n      </mat-error>\n\n      <mat-error *ngIf=\"lastname.hasError('minlength')\">\n        <small style=\"color: red; margin-left: 5px;\" errors>Last name must have atleast 3 letters</small>\n      </mat-error>\n    </div>\n  \n    <ion-item>\n      <ion-label color=\"ourtheme\" position=\"floating\">Student Number</ion-label>\n      <ion-input [disabled]=\"!isEditable\" (ionInput)=\"phoneEnable()\" formControlName=\"studentNumber\" type=\"number\" max=\"9\" enterkeyhint=\"next\">\n  \n      </ion-input>\n      \n    </ion-item>\n\n    <div *ngIf=\"stenabled\">\n\n      <mat-error *ngIf=\"studentNumber.hasError('required')\">\n        <small errors style=\"color: red; margin-left: 5px;\" errors>Student number is <strong><span style=\"letter-spacing: .5px;\">required</span></strong></small>\n      </mat-error>\n\n      <mat-error *ngIf=\"studentNumber.hasError('minlength')\">\n        <small style=\"color: red; margin-left: 5px;\" errors>Student number must have 9 digits</small>\n      </mat-error>\n\n      <mat-error *ngIf=\"studentNumber.hasError('maxlength')\">\n        <small style=\"color: red; margin-left: 5px;\" errors>Student number must have 9 digits</small>\n      </mat-error>\n\n      <mat-error *ngIf=\"studentNumber.hasError('pattern')\">\n        <small style=\"color: red; margin-left: 5px;\" errors>Student number must have 9 digits</small>\n      </mat-error>\n\n    </div>\n  \n  </form>\n\n  <ion-button [disabled]=\"!isEditable || signupForm.status == 'INVALID'\" size=\"small\" expand=\"block\" color=\"ourtheme\" (click)=\"update()\">Update</ion-button>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_account_account_module_ts.js.map